import os
import threading
import time
import subprocess
import re
import sqlite3
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

current_dir = os.path.dirname(os.path.realpath(__file__))
db_path = os.path.join(current_dir, 'ping_data.db')

# initdb
def initialize_db():
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS ping_history
                          (ip_address TEXT, time TEXT, ping_time REAL, loss_time TEXT)''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS ip_names
                          (ip_address TEXT PRIMARY KEY, custom_name TEXT)''')
        conn.commit()

initialize_db()

class PingMonitor:
    def __init__(self, ip_addresses, interface="br0", interval=1):
        self.ip_addresses = ip_addresses
        self.interface = interface
        self.interval = interval
        self.start_monitoring()

    def start_monitoring(self):
        for ip_address in self.ip_addresses:
            threading.Thread(target=self._run_ping, args=(ip_address,)).start()

    def _run_ping(self, ip_address):
        while True:
            cmd = ['ping', '-I', self.interface, '-c', '1', ip_address]
            ping_process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            output, _ = ping_process.communicate()
            output = output.decode('utf-8')
            ping_time = self.parse_ping_output(output)
            timestamp = time.strftime("%Y-%m-%d %H:%M:%S")

            if ping_time is not None:
                self.update_history(ip_address, timestamp, ping_time, None)
            else:
                self.update_history(ip_address, timestamp, None, timestamp)

            time.sleep(self.interval)

    @staticmethod
    def parse_ping_output(output):
        pattern = r"time=([\d.]+) ms"
        match = re.search(pattern, output)
        return float(match.group(1)) if match else None

    def update_history(self, ip_address, timestamp, ping_time, loss_time):
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO ping_history (ip_address, time, ping_time, loss_time) VALUES (?, ?, ?, ?)",
                           (ip_address, timestamp, ping_time, loss_time))
            conn.commit()

@app.route('/')
def index():
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        ip_addresses = []
        cursor.execute('SELECT ip_address, custom_name FROM ip_names')
        for row in cursor.fetchall():
            ip_addresses.append({'ip': row[0], 'name': row[1] if row[1] else row[0]})
        # Fall back to default names if the database is empty
        if not ip_addresses:
            ip_addresses = [{'ip': ip, 'name': ip} for ip in ['1.1.1.1', '2.2.2.2', '3.3.3.3', '4.4.4.4', '5.5.5.5', '6.6.6.6', '7.7.7.7']]
    ping_monitor = PingMonitor([ip['ip'] for ip in ip_addresses])
    return render_template('index.html', ip_addresses=ip_addresses)

@app.route('/stats')
def stats():
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        stats = {}
        for ip_address in ['1.1.1.1', '2.2.2.2', '3.3.3.3', '4.4.4.4', '5.5.5.5', '6.6.6.6', '7.7.7.7']:
            cursor.execute('''
                SELECT AVG(ping_time) as avg_ping, MAX(ping_time) as max_ping, MIN(ping_time) as min_ping,
                (SELECT COUNT(*) FROM ping_history WHERE ping_time IS NULL AND ip_address = ?) * 100.0 /
                (CASE WHEN COUNT(*) = 0 THEN 1 ELSE COUNT(*) END) as packet_loss,
                (SELECT time FROM ping_history WHERE ping_time IS NULL AND ip_address = ? ORDER BY time DESC LIMIT 1) as last_loss_time
                FROM ping_history WHERE ip_address = ?''', (ip_address, ip_address, ip_address))
            avg_max_min_loss_last_loss = cursor.fetchone()

            current_ping = "N/A"
            if avg_max_min_loss_last_loss[0] is not None:
                cursor.execute('''
                    SELECT ping_time FROM ping_history
                    WHERE ip_address = ? AND ping_time IS NOT NULL
                    ORDER BY time DESC LIMIT 1''', (ip_address,))
                most_recent_ping = cursor.fetchone()
                current_ping = f"{most_recent_ping[0]} ms" if most_recent_ping else "N/A"

            stats[ip_address] = {
                'Average_Ping': f"{avg_max_min_loss_last_loss[0]:.2f} ms" if avg_max_min_loss_last_loss[0] else "N/A",
                'Max_Ping': f"{avg_max_min_loss_last_loss[1]} ms" if avg_max_min_loss_last_loss[1] else "N/A",
                'Min_Ping': f"{avg_max_min_loss_last_loss[2]} ms" if avg_max_min_loss_last_loss[2] else "N/A",
                'Packet_Loss_Percentage': f"{avg_max_min_loss_last_loss[3]:.2f}%" if avg_max_min_loss_last_loss[3] is not None else "0%",
                'Current_Ping': current_ping,
                'Last_Loss_Time': avg_max_min_loss_last_loss[4] if avg_max_min_loss_last_loss[4] else "N/A",
            }
    return jsonify(stats)

@app.route('/update-name', methods=['POST'])
def update_name():
    data = request.json
    ip_address = data['ip']
    new_name = data['newName']

    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO ip_names (ip_address, custom_name) VALUES (?, ?)
                          ON CONFLICT(ip_address) DO UPDATE SET custom_name=excluded.custom_name''', 
                       (ip_address, new_name))
        conn.commit()

    return jsonify({"success": True, "ip": ip_address, "newName": new_name})

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8010)
